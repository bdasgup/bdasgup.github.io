#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define CUTOFF 200
#define ERROR 1.e-12

double exp_mean(double r)
{	int i;
	double s,p,q;
	p=1.; r=exp(-r);
	s=0.; q=0.;
	for(i=0;i<CUTOFF;i++){ q+=p; s+=i*p; p*=r;}
	return s/q;
}

double pow_mean(double r)
{	int i;
	double s,p,q;
	s=0.; q=1.;
	for(i=1;i<CUTOFF;i++){ p=pow(i,-r); q+=p; s+=i*p;}
	return s/q;
}

int exp_rand(double r)
{	int n,m;
	double p,q;
	while(1)
	{	n=rand()%CUTOFF;
		p=exp(-r*n)*RAND_MAX;
		m=rand();
		if(m)
		{ if(m<p) return n;}
		else
		{	m=rand(); p*=RAND_MAX;
			if(m<p) return n;
		}
	}
}

int pow_rand(double r)
{	int n,m;
	double p,q;
	while(1)
	{	n=rand()%(CUTOFF);
		p=(n?pow(n,-r):1)*RAND_MAX;
		m=rand();
		if(m)
		{ if(m<p) return n;}
		else
		{	m=rand(); p*=RAND_MAX;
			if(m<p) return n;
		}
	}
}

double ppow,pexp;
int *ind,*outd,*A,*B;

void usage()
{	fprintf(stderr,"parameters:\n\
-V <#vvv> - expected number of vertices; required\n\
-E <#eee> - expected number of edges\n\
-L <#lll> - parameter for exponential distribution: Pr[in-degree=x] ~ L exp(-Lx)\n\
\teither -E or -L parameter required, but not both!\n\
-N <#nnn> - probability for negative edge, 0.0 - 1.0; default: 0.0\n\
-C <#ccc> - probability for critical edge, 0.0 - 1.0; default: 0.0\n\
");



}


main(int argc,char*argv[])
{	int i,j,k,m,N,M;
	int V;
	double E,Cr,Ng,L;
	double a,b,c,d;

///// Reading arguments
	V=-1; E=-1; L=-1; Ng=0; Cr=0;
	
	for(i=1;i<argc;i++)
	{	if(argv[i][0]=='-' || argv[i][0]=='/') switch(argv[i][1])
		{	case 'v': case 'V':
				if(argv[i][2])
				{	k=sscanf(argv[i]+2,"%d",&V);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);}
				else if(i+1<argc)
				{	k=sscanf(argv[i+1],"%d",&V);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);
					else i++;
				}
				else fprintf(stderr,"argument ignored: %s\n",argv[i]);
				break;
			case 'e': case 'E':
				if(argv[i][2])
				{	k=sscanf(argv[i]+2,"%lg",&E);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);}
				else if(i+1<argc)
				{	k=sscanf(argv[i+1],"%lg",&E);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);
					else i++;
				}
				else fprintf(stderr,"argument ignored: %s\n",argv[i]);
				break;
			case 'l': case 'L':
				if(argv[i][2])
				{	k=sscanf(argv[i]+2,"%lg",&L);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);}
				else if(i+1<argc)
				{	k=sscanf(argv[i+1],"%lg",&L);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);
					else i++;
				}
				else fprintf(stderr,"argument ignored: %s\n",argv[i]);
				break;
			case 'c': case 'C':
				if(argv[i][2])
				{	k=sscanf(argv[i]+2,"%lg",&Cr);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);}
				else if(i+1<argc)
				{	k=sscanf(argv[i+1],"%lg",&Cr);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);
					else i++;
				}
				else fprintf(stderr,"argument ignored: %s\n",argv[i]);
				break;
			case 'n': case 'N':
				if(argv[i][2])
				{	k=sscanf(argv[i]+2,"%lg",&Ng);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);}
				else if(i+1<argc)
				{	k=sscanf(argv[i+1],"%lg",&Ng);
					if(!k) fprintf(stderr,"argument ignored: %s\n",argv[i]);
					else i++;
				}
				else fprintf(stderr,"argument ignored: %s\n",argv[i]);
				break;

			default:
				fprintf(stderr,"argument ignored: %s\n",argv[i]);
		}
	}
	bool ok=true;
	if(V==-1) ok=false;
	if(ok && V<1){ fprintf(stderr,"bad argument V %d\n",V); ok=false;}
	if(ok && E==-1 && L==-1) ok=false;
	if(ok && E!=-1 && L!=-1) ok=false;
	if(ok && E!=-1 && E<0){ fprintf(stderr,"bad argument E %lg\n",E); ok=false;}
	if(ok && (Cr<0 || Cr>1)){ fprintf(stderr,"bad argument C %lg\n",Cr); ok=false;}
	if(ok && (Ng<0 || Ng>1)){ fprintf(stderr,"bad argument N %lg\n",Ng); ok=false;}
	if(!ok){ usage(); return 0;}

	if(L!=-1){ pexp=L; d=exp_mean(L); E=d*V;}
	else
	{	d=E/V;
		a=0; b=1; c=0;
		while(c!=(a+b)/2)
		{	c=(a+b)/2;
			if(exp_mean(c)<d) b=c;
			else a=c;
			if(b-a<ERROR) break;
		}
		pexp=c; L=c;
	}
	a=0; b=8; c=0;
	while(c!=(a+b)/2)
	{	c=(a+b)/2;
		if(pow_mean(c)<d) b=c;
		else a=c;
		if(b-a<ERROR) break;
	}
	ppow=c;
	printf("### expected number of edges: %lg\n",E);
	printf("### parameter for exponential distribution: %lg\n",pexp);
	printf("### parameter for power distribution: %lg\n\n",ppow);

	srand(time(0));

	N=V;
	ind=new int[N]; outd=new int[N];
	k=0; m=0;
	for(i=0;i<N;i++)
	{	ind[i]=exp_rand(pexp); outd[i]=pow_rand(ppow);
		k+=ind[i]; m+=outd[i];
	}

	while(k!=m)
	{	i=rand()%N;
		k-=ind[i]; m-=outd[i];
		ind[i]=exp_rand(pexp); outd[i]=pow_rand(ppow);
		k+=ind[i]; m+=outd[i];
		//printf("in: %d\tout: =%d\n",k,m);
	}
	//printf("### k=%d m=%d\n",k,m);

	A=new int[m]; B=new int[m];
	k=0;
	for(i=0;i<N;i++) for(j=0;j<ind[i];j++){ A[k]=i; k++;}
	k=0;
	for(i=0;i<N;i++) for(j=0;j<outd[i];j++){ B[k]=i; k++;}
	for(i=m;i>1;i--)
	{	k=rand()%i; j=B[k]; B[k]=B[i-1]; B[i-1]=j;
	}
	M=m;
	for(i=0;i<m;i++) if(A[i]==B[i]) M--;

	a=Ng*RAND_MAX; b=Cr*RAND_MAX;
	for(i=0;i<m;i++)
	{	if(A[i]==B[i]) continue;
		printf("%d\t-%c\t%d",A[i],rand()>a?'>':'|',B[i]);
		if(rand()<b) printf("\tY");
		printf("\n",A[i],B[i]);
	}

	printf("\n### created %d vertices; %d edges\n",N,M);

	delete[] ind; delete[] outd;
	delete[] A; delete[] B;
}

/*
Directed graph should be generated strictly according to the Physical review paper.

Number of nodes: of the order of 1000s (i.e., say between 1000 and 5000)

Distribution of in-degree of the network is exponential:

  Pr[in-degree=x] = L exp(-Lx)
  L is between 1/2 to 1/3
  maximum in-degree is 12

Distribution of out-degree of the network is power-law:

   For x>=1,  Pr[out-degree=x]=c x^{-c}, c is between 2 and 3
                                         (c~2.2 for (undirected) protein interaction networks)
   For x=0,   Pr[out-degree=0]>=c
              (idea: plot the graph Pr[out-degree+1=x] and roughly follow the first point)

   maximum out-degree is 200
*/
