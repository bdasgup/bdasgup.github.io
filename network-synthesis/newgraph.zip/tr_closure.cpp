#include <stdio.h>
#include <string>
#include <vector>
#include "tred.h"

using namespace std;

int Sz,NN=-1;
int *NNN;

CMatr* tr_closure(std::vector<CVert*>&VV,std::vector<CEdge*>&EE)
{	int i,j,k;
	Sz=VV.size();
	int n=Sz*Sz;
	CMatr *M=new CMatr(VV,EE);
	char *Ppos,*Pneg;
//print_matr(M);
	Ppos=new char[Sz*Sz];
	Pneg=new char[Sz*Sz];
	for(i=0;i<n;i++)
	{	Ppos[i]=0; Pneg[i]=0;}

	for(i=0;i<EE.size();i++)
	{	if(EE[i]->is_inactive()) continue;
		if(EE[i]->is_positive())
			Ppos[EE[i]->A->D*Sz + EE[i]->B->D]=1;
		if(EE[i]->is_negative())
			Pneg[EE[i]->A->D*Sz + EE[i]->B->D]=1;
	}
	//	Floyd-Warshal cycle
	for(k=0;k<Sz;k++)
	{	for(i=0;i<Sz;i++)
		{	if(i==k) continue;
			if(Ppos[i*Sz+k]) for(j=0;j<Sz;j++)
			{	if(j==i || j==k) continue;
				if(Ppos[k*Sz+j]) Ppos[i*Sz+j]=1;
				if(Pneg[k*Sz+j]) Pneg[i*Sz+j]=1;
			}
			if(Pneg[i*Sz+k]) for(j=0;j<Sz;j++)
			{	if(j==i || j==k) continue;
				if(Ppos[k*Sz+j]) Pneg[i*Sz+j]=1;
				if(Pneg[k*Sz+j]) Ppos[i*Sz+j]=1;
			}
		}
	}

	for(i=0;i<n;i++)
	{	M->Apos[i]=Ppos[i];
		M->Aneg[i]=Pneg[i];
	}
	delete[] Ppos;
	delete[] Pneg;
//print_matr(M);
	return M;
}

CMatr* tr_closure_ex(std::vector<CVert*>&VV,std::vector<CEdge*>&EE,CVert*A)
{	int i,j,k;
	Sz=VV.size();
	int n=Sz*Sz;
	CMatr *M=new CMatr(VV,EE);
	char *Ppos,*Pneg;
//print_matr(M);
	Ppos=new char[Sz*Sz];
	Pneg=new char[Sz*Sz];
	for(i=0;i<n;i++)
	{	Ppos[i]=0; Pneg[i]=0;}

	for(i=0;i<EE.size();i++)
	{	if(EE[i]->is_inactive()) continue;
		if(EE[i]->A==A || EE[i]->B==A) continue;
		if(EE[i]->is_positive())
			Ppos[EE[i]->A->D*Sz + EE[i]->B->D]=1;
		if(EE[i]->is_negative())
			Pneg[EE[i]->A->D*Sz + EE[i]->B->D]=1;
	}
	//	Floyd-Warshal cycle
	for(k=0;k<Sz;k++)
	{	for(i=0;i<Sz;i++)
		{	if(i==k) continue;
			if(Ppos[i*Sz+k]) for(j=0;j<Sz;j++)
			{	if(j==i || j==k) continue;
				if(Ppos[k*Sz+j]) Ppos[i*Sz+j]=1;
				if(Pneg[k*Sz+j]) Pneg[i*Sz+j]=1;
			}
			if(Pneg[i*Sz+k]) for(j=0;j<Sz;j++)
			{	if(j==i || j==k) continue;
				if(Ppos[k*Sz+j]) Pneg[i*Sz+j]=1;
				if(Pneg[k*Sz+j]) Ppos[i*Sz+j]=1;
			}
		}
	}

	for(i=0;i<n;i++)
	{	M->Apos[i]=Ppos[i];
		M->Aneg[i]=Pneg[i];
	}
	delete[] Ppos;
	delete[] Pneg;
//print_matr(M);
	return M;
}
