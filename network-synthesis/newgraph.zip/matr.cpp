#include <stdio.h>
#include <string>
#include <vector>
#include "tred.h"

using namespace std;

CMatr::CMatr(std::vector<CVert*>&V,std::vector<CEdge*>&E)
{	int i;
	Sz=V.size();
	VV=new CVertPtr[Sz];
	Apos=new char[Sz*Sz]; memset(Apos,0,Sz*Sz);
	Aneg=new char[Sz*Sz]; memset(Aneg,0,Sz*Sz);
	for(i=0;i<Sz;i++){ VV[i]=V[i]; VV[i]->D=i;}
//return;
	for(i=0;i<E.size();i++)
	{	if(E[i]->is_inactive()) continue;
		if(E[i]->is_positive()) Apos[E[i]->A->D*Sz + E[i]->B->D]=1;
		if(E[i]->is_negative()) Aneg[E[i]->A->D*Sz + E[i]->B->D]=1;
	}
}

bool CMatr::path_exist(int x,int y,char b)
{	switch(b)
	{	case 0: return Apos[x*Sz+y];
		case 1: return Aneg[x*Sz+y];
	}
}

void print_matr(CMatr*M)
{
	int i,j;
//	char c;
//	M->Sz;
	for(i=0;i<M->Sz;i++)
	{	for(j=0;j<M->Sz;j++)
		{	if(j==i) continue;
			if(M->Apos[i*M->Sz+j])
				printf("%d -> %d\n",i,j);
			if(M->Aneg[i*M->Sz+j])
				printf("%d -| %d\n",i,j);
		}
	}
printf("\n");
}

bool CMatr::operator==(const CMatr&M)
{	int i,k;
	if(Sz!=M.Sz) return false;
	k=Sz*Sz;
	for(i=0;i<k;i++)
	{	if(Apos[i]!=M.Apos[i]) return false;
		if(Aneg[i]!=M.Aneg[i]) return false;
	}
	return true;
}

bool CMatr::same_inout(int x,int y)
{	int i;

	for(i=0;i<Sz;i++)
	{	if(i==x||i==y) continue;
		if(Apos[i*Sz+x]!=Apos[i*Sz+y]) return false;
		if(Apos[x*Sz+i]!=Apos[y*Sz+i]) return false;
		if(Aneg[i*Sz+x]!=Aneg[i*Sz+y]) return false;
		if(Aneg[x*Sz+i]!=Aneg[y*Sz+i]) return false;
	}
	if(Apos[y*Sz+x]!=Apos[x*Sz+y]) return false;
	if(Aneg[y*Sz+x]!=Aneg[x*Sz+y]) return false;
	return true;
}

bool CMatr::empty_inout(int x)
{	int i;
	for(i=0;i<Sz;i++)
	{	if(Apos[i*Sz+x]) return false;
		if(Apos[x*Sz+i]) return false;
		if(Aneg[i*Sz+x]) return false;
		if(Aneg[x*Sz+i]) return false;
	}
	return true;
}
