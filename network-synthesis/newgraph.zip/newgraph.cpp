#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <vector>
#include <algorithm>
#include "tred.h"

using namespace std;

vector<CVert*> VV,VV0;
vector<CEdge*> EE,EE1;
vector<CInd*> II;

main(int argc,const char*argv[])
{	int i,j,n;
	bool b;
	CVert *V1,*V2;
	CEdge *E;
	CInd *I;
	CMatr *M,*M1;
	vector<CVert*> D;

	srand(time(0));

	if(argc<2){ fprintf(stderr,"Please specify the input file!\n"); return 0;}

	read_file(argv[1],VV,EE,II);

	printf("### input: %d vertices, %d interactions, %d indirect interactions\n",VV.size(),EE.size(),II.size());
	//stable_sort(EE.begin(),EE.end(),abless);
	clean_red(EE);
	printf("\n### %d non redundant edges\n",EE.size());

	report_scc(VV,EE);

//	for(i=0;i<EE.size();i++) print_edge(EE[i]);

////////////////////////////
//                        //
//  CREATING PSEUDONODES  //
//                        //
////////////////////////////

	for(i=0;i<II.size();i++)
	{	printf("### ");
		print_ind(II[i]);
		I=II[i];
		E=find_edge(EE,I->B,I->C,I->bc());
		if(E && E->is_critical())
		{	printf("### critical edge\n");
			if(find_edge(EE,I->A,I->B,I->ab())) continue;
			printf("### new edge added\n");
			E=new CEdge; E->F=I->ab()?2:1;
			E->A=I->A; E->B=I->B;
			EE.push_back(E); continue;
		}
		b=0;

//const char* kala=I->A->Name.c_str();
//const char* kalb=I->B->Name.c_str();
//const char* kalc=I->C->Name.c_str();
//int dsize=D.size();

		M=tr_closure_ex(VV,EE,I->A);
		for(j=0;j<VV.size();j++)
		{	if(!M->path_exist(I->B->D,VV[j]->D,0)) continue;
			if(!M->path_exist(VV[j]->D,I->C->D,I->bc())) continue;
//const char* kald=VV[j]->Name.c_str();
			D.push_back(VV[j]);
		}
		delete M; M=tr_closure_ex(VV,EE,I->B);
//dsize=D.size();
		for(j=0;j<D.size();j++)
		{	if(M->path_exist(I->A->D,D[j]->D,I->ab())) break;}
		if(j<D.size()) b=1;

		delete M; D.clear();

		if(b)
		{	printf("### path exists\n"); continue;}

		V1=new CVert("*");
		V1->Name+=I->A->Name; V1->Name+=I->ab()?"-|":"->";
		V1->Name+=I->B->Name; V1->Name+=I->bc()?"-|":"->";
		V1->Name+=I->C->Name; VV.push_back(V1);

		E=new CEdge; E->A=I->B; E->B=V1; E->F=1;
		EE.push_back(E);
		E=new CEdge; E->A=I->A; E->B=V1; E->F=I->ab()?2:1;
		EE.push_back(E);
		E=new CEdge; E->A=V1; E->B=I->C; E->F=I->bc()?2:1;
		EE.push_back(E);
		//fprintf(stderr,"creating pseudonode %s\n",V1->Name.c_str());
		printf("### pseudonode created: %s\n",V1->Name.c_str());
		VV0.push_back(V1);
	}
	for(i=0;i<II.size();i++) delete II[i];

////////////////////////////
//                        //
//  COLLAPSE PSEUDONODES  //
//                        //
////////////////////////////

	if(II.size())
	{	printf("\n### %d edges before collapse\n",EE.size());

		M=tr_closure(VV,EE);
		for(i=0;i<VV0.size();i++) for(j=i+1;j<VV0.size();j++)
		{	if(!M->same_inout(VV0[i]->D,VV0[j]->D)) continue;
			fprintf(stderr,"collapsing pseudonode %s\n",VV0[i]->Name.c_str());
			for(n=0;n<EE.size();n++)
			{	if(EE[n]->A==VV0[i]) EE[n]->A=VV0[j];
				if(EE[n]->B==VV0[i]) EE[n]->B=VV0[j];
			}
			break;
		}
		delete M;

		M=tr_closure(VV,EE);
		for(i=0;i<VV0.size();i++)
		{	if(M->empty_inout(VV0[i]->D)) continue;
			for(j=0;j<VV.size();j++)
			{	if(VV0[i]==VV[j]) continue;
				if(M->same_inout(VV0[i]->D,VV[j]->D)) break;}
			if(j<VV.size())
			{	printf("### collapsing pseudonode %s\n",VV0[i]->Name.c_str());
				for(n=0;n<EE.size();n++)
					if(EE[n]->A==VV0[i] || EE[n]->B==VV0[i]) EE[n]->set_inactive();
			}
		}
		delete M;
		clean_red(EE);

		printf("\n### %d edges after collapse\n",EE.size());

		report_scc(VV,EE);
	}
	II.clear();
//return 0;
////////////////////////////
//                        //
//  TRANSITIVE REDUCTION  //
//                        //
////////////////////////////

	M=tr_closure(VV,EE);
	for(i=0;i<EE.size();i++)
	{	if(EE[i]->is_critical()) continue;
		if(EE[i]->is_inactive()) continue;
		EE[i]->set_inactive();
//fprintf(stderr,"checking edge %d / %d\n",i,EE.size());
		M1=tr_closure(VV,EE);
		if(*M1!=*M) EE[i]->set_active();
		delete M1;
	}
	//print_matr(M);
	delete M;
	j=0;

	printf("\n");
	for(i=0;i<EE.size();i++)
	{	if(EE[i]->is_inactive())
		{	printf("### deleting edge:\t"); print_edge(EE[i]);
			delete EE[i]; continue;}
		EE[j]=EE[i]; j++;
	}
	EE.resize(j);
	printf("\n### %d output edges\n",EE.size());
	for(i=0;i<EE.size();i++) print_edge(EE[i]);
}