class CEdge;

class CVert
{
public:
	std::string Name;
	int D,F,E;
	CVert *P;
	CVert(std::string s){ Name=s; P=0;}
	CVert(const char*s){ Name=s; P=0;}
};

class CEdge
{
public:
	CVert *A,*B;
	char F;	// 1:+, 2:-, 4:!, 8:marked, 16:inactive, 32: neutral
	bool is_positive(){ return F&1;}
	bool is_negative(){ return F&2;}
	bool is_neutral(){ return F&32;}
	bool is_both(){ return (F&3)==3;}
	bool is_critical(){ return F&4;}
	bool is_marked(){ return F&8;}
	void unmark(){ F&=0x17;}
	void mark(){ F|=8;}
	bool is_inactive(){ return F&16;}
	void set_positive(){ F=1;}
	void set_negative(){ F=2;}
	void set_neutral(){ F=32;}
	void set_active(){ F&=0xef;}
	void set_inactive(){ F|=16;}
};

class CInd
{
public:
	CVert *A,*B,*C;
	char F;
	bool ab(){ return F&1;}
	bool bc(){ return F&2;}
};

typedef CVert* CVertPtr;

class CMatr
{
public:
	int Sz;
	CVertPtr *VV;
	char *Apos,*Aneg;
	CMatr(){ Sz=0; VV=0; Apos=0; Aneg=0;}
	CMatr(std::vector<CVert*>&,std::vector<CEdge*>&);
	~CMatr(){ if(VV){ delete[] VV; delete[] Apos; delete[] Aneg;}}
	bool operator==(const CMatr&);
	bool operator!=(const CMatr&M){ return !operator==(M);}
	bool path_exist(int x,int y,char b);
	bool same_inout(int x,int y);
	bool empty_inout(int x);
};

inline bool abless(CEdge*X,CEdge*Y)
{	if(X->A<Y->A) return true;
	if(X->A>Y->A) return false;
	if(X->B<Y->B) return true;
	if(X->B>Y->B) return false;
	return X->F>Y->F;
}

inline bool baless(CEdge*X,CEdge*Y)
{	if(X->B<Y->B) return true;
	if(X->B>Y->B) return false;
	if(X->A<Y->A) return true;
	if(X->A>Y->A) return false;
	return X->F>Y->F;
}

inline bool revfless(CVert*X,CVert*Y)
{	return X->F>Y->F;}

void print_edge(CEdge*E);
void print_ind(CInd*E);
bool read_file(const char *,std::vector<CVert*>&,std::vector<CEdge*>&,std::vector<CInd*>&);
bool write_file(const char *,std::vector<CVert*>&,std::vector<CEdge*>&);
void print_matr(CMatr*M);
CMatr* tr_closure(std::vector<CVert*>&,std::vector<CEdge*>&);

CEdge* find_edge(std::vector<CEdge*>&,CVert*,CVert*,bool);
CMatr* tr_closure_ex(std::vector<CVert*>&,std::vector<CEdge*>&,CVert*);

void clean_red(std::vector<CEdge*>&);
void heur_clean(std::vector<CVert*>&,std::vector<CEdge*>&);
void copy(std::vector<CVert*>&,std::vector<CEdge*>&,std::vector<CVert*>&,std::vector<CEdge*>&);
void dfs(std::vector<CVert*>&,std::vector<CEdge*>&);
void scc(std::vector<CVert*>&,std::vector<CEdge*>&);
void report_scc(std::vector<CVert*>&,std::vector<CEdge*>&);
