#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <vector>
#include <algorithm>
#include "tred.h"

using namespace std;

void dfs(vector<CVert*>&VV,vector<CEdge*>&EE)
{	int i,t;
	CVert *V,*V1;

	stable_sort(EE.begin(),EE.end(),abless);

	for(i=0;i<VV.size();i++)
	{	VV[i]->D=0; VV[i]->F=0; VV[i]->P=VV[i]; VV[i]->E=-1;}

	for(i=0;i<EE.size();i++) if(EE[i]->A->E==-1) EE[i]->A->E=i;

	t=1;
	for(i=0;i<VV.size();i++)
	{	if(VV[i]->D) continue;
		V=VV[i]; V->D=t; t++;
		while(1)
		{	if(V->E!=-1 && V->E<EE.size() && EE[V->E]->A==V)
			{	V1=EE[V->E]->B; V->E++;
				if(!V1->D){ V1->D=t; t++; V1->P=V; V=V1;}
				continue;
			}
			else
			{	V->F=t; t++;
				if(V->P==V) break;
				else V=V->P;
			}
		}
	}
}

void scc(vector<CVert*>&VV,vector<CEdge*>&EE)
{	int i,t;
	CVert *V,*V0,*V1;

	dfs(VV,EE);
	stable_sort(VV.begin(),VV.end(),revfless);
	stable_sort(EE.begin(),EE.end(),baless);

	for(i=0;i<VV.size();i++)
	{	VV[i]->D=0; VV[i]->F=0; VV[i]->P=VV[i]; VV[i]->E=-1;}

	for(i=0;i<EE.size();i++) if(EE[i]->B->E==-1) EE[i]->B->E=i;

	t=1;
	for(i=0;i<VV.size();i++)
	{	if(VV[i]->D) continue;
		V=VV[i]; V->D=t; t++;
		while(1)
		{	if(V->E!=-1 && V->E<EE.size() && EE[V->E]->B==V)
			{	V1=EE[V->E]->A; V->E++;
				if(!V1->D){ V1->D=t; t++; V1->P=V; V=V1;}
				continue;
			}
			else
			{	V->F=t; t++;
				if(V->P==V) break;
				else V=V->P;
			}
		}
	}
	for(i=0;i<VV.size();i++)
	{	for(V=VV[i];V->P!=V;V=V->P);
		for(V1=VV[i];V1!=V;V1=V0){ V0=V1->P; V1->P=V;}
	}
}

void report_scc(vector<CVert*>&VV,vector<CEdge*>&EE)
{	int i,j,k,n;
	int *Sz;	// size of component
	scc(VV,EE);
	n=0;
	for(i=0;i<VV.size();i++) if(VV[i]->P==VV[i]) n++;
	Sz=new int[n]; for(i=0;i<n;i++) Sz[i]=0;
	printf("### %d vertices in %d strongly connected components:\n",VV.size(),n);

	n=0;
	for(i=0;i<VV.size();i++) if(VV[i]->P==VV[i]){ VV[i]->D=n; n++;}
	for(i=0;i<VV.size();i++) Sz[VV[i]->P->D]++;
	stable_sort(Sz,Sz+n);
	j=0;
	for(i=0;i<n;i++)
	{	if(Sz[i]!=j)
		{	if(j) printf("### %d component%s of size %d\n",k,k>1?"s":"",j);
			j=Sz[i]; k=0;
		}
		k++;
	}
	printf("### %d component%s of size %d\n",k,k>1?"s":"",j);
}
