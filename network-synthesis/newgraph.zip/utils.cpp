#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include "tred.h"

using namespace std;

void print_edge(CEdge*E)
{	printf("%s\t",E->A->Name.c_str());
	if(E->F&1) printf("->");
	if(E->F&2) printf("-|");
	if(E->F&32) printf("-:");
	printf("\t%s",E->B->Name.c_str());
	if(E->F&4) printf("\tY");
	printf("\n");
}

void print_ind(CInd*I)
{	printf("%s\t-%c\t(\t%s\t-%c\t%s\t)\n",I->A->Name.c_str(),
		I->F&1?'|':'>',I->B->Name.c_str(),
		I->F&2?'|':'>',I->C->Name.c_str());
}

void print_vertex(CVert*V)
{	printf("%s\t%d/%d",V->Name.c_str(),V->D,V->F);
	if(V->P) printf("\t%s",V->P->Name.c_str());
	printf("\n");
}

bool read_file(const char *file,std::vector<CVert*>&VV,std::vector<CEdge*>&EE,std::vector<CInd*>&II)
{	int i,j,n;
	char buff[10000],b1[1000],s1[1000],s2[1000],s3[1000],s4[1000],s5[1000];
	FILE *fp;
	CVert *V1,*V2,*V3;
	CEdge *E;
	CInd *I;
	map<string,CVert*> VM;
	map<string,CVert*>::iterator J;

	fp=fopen(file,"r");
	if(!fp){ fprintf(stderr,"Cannot open file %s\n",file); return 0;}
	while(fscanf(fp,"%[^\n]",buff)!=EOF)
	{	fscanf(fp,"\n");
		for(i=0;buff[i];i++) if(buff[i]=='#'){ buff[i]=0; break;}
		s4[0]=0;


		n=sscanf(buff,"%s %s (%[^()])",s1,s2,b1);
		if(n==3)
		{	n=sscanf(b1,"%s %s %s",s3,s4,s5);
			if(n<3){ fprintf(stderr,"Line ignored: %s%d\n",buff,n); continue;}
			if(s2[0]!='-' || s2[2] || (s2[1]!='>' && s2[1]!='|')){ fprintf(stderr,"Line ignored: %s\n",buff); continue;}
			if(s4[0]!='-' || s4[2] || (s4[1]!='>' && s4[1]!='|')){ fprintf(stderr,"Line ignored: %s\n",buff); continue;}
//printf("%d %s [%s]\n",n,buff,b1);

			J=VM.find(s1);
			if(J!=VM.end()) V1=J->second;
			else { V1=new CVert(s1); VM[s1]=V1;}
			J=VM.find(s3);
			if(J!=VM.end()) V2=J->second;
			else { V2=new CVert(s3); VM[s3]=V2;}
			J=VM.find(s5);
			if(J!=VM.end()) V3=J->second;
			else { V3=new CVert(s5); VM[s5]=V3;}

			I=new CInd; I->A=V1; I->B=V2; I->C=V3; I->F=0;
			if(s2[1]=='|') I->F=1;
			if(s4[1]=='|') I->F+=2;
			II.push_back(I);

			continue;
		}
		n=sscanf(buff,"%s %s %s %s",s1,s2,s3,s4);
		if(n<1) continue;
		if(n<3){ fprintf(stderr,"Line ignored: %s%d\n",buff,n); continue;}
		if(s2[0]!='-' || s2[2] || (s2[1]!='>' && s2[1]!='|' && s2[1]!=':')){ fprintf(stderr,"Line ignored: %s\n",buff); continue;}

		J=VM.find(s1);
		if(J!=VM.end()) V1=J->second;
		else { V1=new CVert(s1); VM[s1]=V1;}
		J=VM.find(s3);
		if(J!=VM.end()) V2=J->second;
		else { V2=new CVert(s3); VM[s3]=V2;}

		E=new CEdge; E->A=V1; E->B=V2; E->F=0;
		if(s2[1]==':') E->set_neutral();
		else if(s2[1]=='>') E->set_positive();
		else E->set_negative();
		if(!strcmp(s4,"Y")) E->F+=4;
		EE.push_back(E);
	}
	for(J=VM.begin();J!=VM.end();J++) VV.push_back(J->second);
}

void copy(std::vector<CVert*>&V0,std::vector<CEdge*>&E0,std::vector<CVert*>&V1,std::vector<CEdge*>&E1)
{	int i;
	CVert *V;
	CEdge *E;

	for(i=0;i<V1.size();i++) delete V1[i];
	for(i=0;i<E1.size();i++) delete E1[i];
	V1.clear(); E1.clear();

	for(i=0;i<V0.size();i++)
	{	V=new CVert(V0[i]->Name); V0[i]->P=V;
		V1.push_back(V);
	}
	for(i=0;i<E0.size();i++)
	{	E=new CEdge; E->F=E0[i]->F;
		E->A=E0[i]->A->P;
		E->B=E0[i]->B->P;
		E1.push_back(E);
	}
}

CEdge* find_edge(std::vector<CEdge*>&EE,CVert*A,CVert*B,bool b)
{	int i;
	for(i=0;i<EE.size();i++)
	{	if(EE[i]->A!=A) continue;
		if(EE[i]->B!=B) continue;
		if(!b && EE[i]->is_positive()) return EE[i];
		if(b && EE[i]->is_negative()) return EE[i];
	}
	return 0;
}

