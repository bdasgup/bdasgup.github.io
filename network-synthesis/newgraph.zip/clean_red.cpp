#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <vector>
#include <algorithm>
#include "tred.h"

using namespace std;

void clean_red(vector<CEdge*>&EE)
{	int i,j;
	char c;
	CVert *a=0,*b=0;
	stable_sort(EE.begin(),EE.end(),abless);

	j=0;
	for(i=0;i<EE.size();i++)
	{	if(a!=EE[i]->A || b!=EE[i]->B){ a=EE[i]->A; b=EE[i]->B; c=0;}
		if(EE[i]->F==7)	//	+-!
		{	c|=1; EE[j]=EE[i]; j++; continue;}
		if(EE[i]->F==5)	//	+!
		{	c|=2; EE[j]=EE[i]; j++; continue;}
		if(EE[i]->F==6)	//	-!
		{	c|=4; EE[j]=EE[i]; j++; continue;}
		if(EE[i]->F==3)	//	+-
		{	if( (c&1) || (c&8) || ((c&2)&&(c&4)) )
			{	printf("### redundant: "); print_edge(EE[i]);
				delete EE[i]; continue;}
			if((c&2))
			{	EE[i]->F=2; c|=32; EE[j]=EE[i]; j++; continue;}
			if((c&4))
			{	EE[i]->F=1; c|=16; EE[j]=EE[i]; j++; continue;}
			c|=8; EE[j]=EE[i]; j++; continue;
		}
		if(EE[i]->F==1)	//	+
		{	if( (c&1) || (c&2) || (c&8) || (c&16) )
			{	printf("### redundant: "); print_edge(EE[i]);
				delete EE[i]; continue;}
			c|=16; EE[j]=EE[i]; j++; continue;
		}
		if(EE[i]->F==2)	//	-
		{	if( (c&1) || (c&4) || (c&8) || (c&32) )
			{	printf("### redundant: "); print_edge(EE[i]);
				delete EE[i]; continue;}
			c|=32; EE[j]=EE[i]; j++; continue;
		}
	}
	EE.resize(j);
}
